console.log("hola");
const primeros4 = document.getElementsByClassName("primeros4")
primeros4[0].style.background = "green"

function getRandom() {
    return Math.round(Math.random()* 7 +1)   
}

let lista = [];



for (let i = 0; i < 8; i++) {
    let num = getRandom();
    if (!lista.includes(num))
        lista.push(getRandom())    
}
console.log(lista);